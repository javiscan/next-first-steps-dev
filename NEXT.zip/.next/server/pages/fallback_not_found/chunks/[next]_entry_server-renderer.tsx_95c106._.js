Error.stackTraceLimit = 100;
global.self = global;
require("./[turbopack-node]_ipc_index.ts_6436c4._.js");
require("./[turbopack-node]_compiled_stacktrace-parser_index_82bc7d.js");
require("./[next]_internal_page-server-handler.tsx_b976fb._.js");
require("./[next]_entry_server-renderer.tsx_3c71c1._.js");
require("./[next]_entry_server-renderer.tsx_ca18c7._.js");
require("./[next]_entry_server-renderer.tsx_dc545f._.js");
