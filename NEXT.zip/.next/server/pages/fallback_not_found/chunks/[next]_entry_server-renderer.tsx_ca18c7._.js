(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "chunks/[next]_entry_server-renderer.tsx_ca18c7._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "chunks/[next]_entry_server-renderer.tsx_ca18c7._.js",
  "chunks": [
    "chunks/[turbopack-node]_ipc_index.ts_6436c4._.js",
    "chunks/[turbopack-node]_compiled_stacktrace-parser_index_82bc7d.js",
    "chunks/[next]_internal_page-server-handler.tsx_b976fb._.js",
    "chunks/[next]_entry_server-renderer.tsx_3c71c1._.js"
  ],
  "source": "entry"
});
