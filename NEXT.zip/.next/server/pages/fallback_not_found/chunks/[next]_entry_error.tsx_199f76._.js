(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["chunks/[next]_entry_error.tsx_199f76._.js", {

"[next]/entry/error.tsx (ecmascript, ecmascript, manifest chunk)": (({ r: __turbopack_require__, x: __turbopack_external_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_cjs__, k: __turbopack_refresh__, g: global, __dirname }) => (() => {

__turbopack_export_value__([
  {
    "path": "chunks/[next]_entry_error.tsx_da0a65._.js",
    "included": [
      "[next]/entry/error.tsx (ecmascript, ecmascript)"
    ]
  },
  "chunks/[next]_entry_error.tsx_69de21._.js"
]);

})()),
}]);