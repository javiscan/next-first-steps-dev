(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["chunks/[next]_entry_error.tsx_da0a65._.js", {

"[next]/entry/error.tsx (ecmascript, ecmascript)": (({ r: __turbopack_require__, x: __turbopack_external_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_cjs__, k: __turbopack_refresh__, g: global, __dirname }) => (() => {

__turbopack_esm__({
    "__N_SSG": ()=>__TURBOPACK__external__next$2f$error__["__N_SSG"],
    "__N_SSP": ()=>__TURBOPACK__external__next$2f$error__["__N_SSP"],
    "default": ()=>__TURBOPACK__external__next$2f$error__["default"],
    "getStaticProps": ()=>__TURBOPACK__external__next$2f$error__["getStaticProps"]
});
var __TURBOPACK__external__next$2f$error__ = __turbopack_external_require__("next/error", true);
"__TURBOPACK__ecmascript__hoisting__location__";
;

})()),
}]);

//# sourceMappingURL=[next]_entry_error.tsx_da0a65._.js.map