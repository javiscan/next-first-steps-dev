(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "chunks/[next]_entry_error.tsx_69de21._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "chunks/[next]_entry_error.tsx_69de21._.js",
  "chunks": [
    "chunks/[next]_entry_error.tsx_da0a65._.js"
  ],
  "source": "dynamic"
});
