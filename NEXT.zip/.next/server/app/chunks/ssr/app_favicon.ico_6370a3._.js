(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["chunks/ssr/app_favicon.ico_6370a3._.js", {

"[project]/app/favicon.ico (static, ssr)": (({ r: __turbopack_require__, x: __turbopack_external_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_cjs__, k: __turbopack_refresh__, g: global, __dirname }) => (() => {

__turbopack_export_value__("/_next/static/media/favicon.45db1c09.ico");
})()),
"[project]/app/favicon.ico/(IMAGE)/[project]/app/favicon.ico (static) (structured image object, ecmascript, ssr)": (({ r: __turbopack_require__, x: __turbopack_external_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_cjs__, k: __turbopack_refresh__, g: global, __dirname }) => (() => {

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$favicon$2e$ico__$28$static$29$__ = __turbopack_import__("[project]/app/favicon.ico (static, ssr)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$favicon$2e$ico__$28$static$29$__["default"],
    width: 256,
    height: 256
};

})()),
}]);

//# sourceMappingURL=app_favicon.ico_6370a3._.js.map