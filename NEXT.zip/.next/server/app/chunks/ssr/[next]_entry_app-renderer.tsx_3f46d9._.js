(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["chunks/ssr/[next]_entry_app-renderer.tsx_3f46d9._.js", {

"[next]/entry/app/hydrate.tsx (ecmascript, chunk group files, ssr)": (({ r: __turbopack_require__, x: __turbopack_external_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_cjs__, k: __turbopack_refresh__, g: global, __dirname }) => (() => {

__turbopack_export_value__([
  "static/chunks/_edd010._.js",
  "static/chunks/[next]_overlay_client.ts_f72f0e._.js",
  "static/chunks/[next]_dev_2185c6._.js",
  "static/chunks/[next]_compiled_platform_index_a1e4df.js",
  "static/chunks/[next]_compiled_css.escape_index_04d239.js",
  "static/chunks/[next]_compiled_strip-ansi_index_a31030.js",
  "static/chunks/[next]_compiled_stacktrace-parser_index_ae8931.js",
  "static/chunks/[next]_compiled_anser_index_f39a28.js",
  "static/chunks/[next]_entry_app_hydrate.tsx_b53fce._.js",
  "static/chunks/[turbopack-dev]_client_3f65d0._.js",
  "static/chunks/[next]_entry_app_hydrate.tsx_16c395._.js",
  "static/chunks/[next]_entry_app_hydrate.tsx_e44c70._.js"
]);

})()),
"[next]/entry/app-renderer.tsx/(COMPONENT_0)/[project]/app/page.tsx (ecmascript, client chunks)/(COMPONENT_1)/[project]/app/layout.tsx (ecmascript, client chunks)/(METADATA_2)/[project]/app/favicon.ico/(IMAGE)/[project]/app/favicon.ico (static) (structured image object, ecmascript)/(BOOTSTRAP)/[next]/entry/app/hydrate.tsx (ecmascript, chunk group files) (ecmascript, ssr)": (({ r: __turbopack_require__, x: __turbopack_external_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_cjs__, k: __turbopack_refresh__, g: global, __dirname }) => (() => {

__turbopack_esm__({
    "htmlEscapeJsonString": ()=>htmlEscapeJsonString
});
var __TURBOPACK__imported__module__$5b$turbopack$2d$node$5d2f$ipc$2f$index$2e$ts__$28$ecmascript$29$__ = __turbopack_import__("[turbopack-node]/ipc/index.ts (ecmascript, ssr)");
var __TURBOPACK__imported__module__$5b$next$5d2f$polyfill$2f$app$2d$polyfills$2e$ts__$28$ecmascript$29$__ = __turbopack_import__("[next]/polyfill/app-polyfills.ts (ecmascript, ssr)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$page$2e$tsx__$28$ecmascript$2c$__client__chunks$29$__ = __turbopack_import__("[project]/app/page.tsx (ecmascript, client chunks, rsc)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$layout$2e$tsx__$28$ecmascript$2c$__client__chunks$29$__ = __turbopack_import__("[project]/app/layout.tsx (ecmascript, client chunks, rsc)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$favicon$2e$ico$2f28$IMAGE$292f5b$project$5d2f$app$2f$favicon$2e$ico__$28$static$29$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__("[project]/app/favicon.ico/(IMAGE)/[project]/app/favicon.ico (static) (structured image object, ecmascript, ssr)");
var __TURBOPACK__imported__module__$5b$next$5d2f$entry$2f$app$2f$hydrate$2e$tsx__$28$ecmascript$2c$__chunk__group__files$29$__ = __turbopack_import__("[next]/entry/app/hydrate.tsx (ecmascript, chunk group files, ssr)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$app$2d$render$2f$app$2d$render$2e$js__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/app-render/app-render.js (ecmascript, ssr)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$app$2d$router$2d$headers$2e$js__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/client/components/app-router-headers.js (ecmascript, ssr)");
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$headers$2e$ts__$28$ecmascript$29$__ = __turbopack_import__("[next]/internal/headers.ts (ecmascript, ssr)");
var __TURBOPACK__external__node$3a$querystring__ = __turbopack_external_require__("node:querystring", true);
var __TURBOPACK__external__node$3a$stream__ = __turbopack_external_require__("node:stream", true);
var __TURBOPACK__imported__module__$5b$next$5d2f$entry$2f$app$2f$layout$2d$entry$2e$tsx__$28$ecmascript$2c$__client__chunks$29$__ = __turbopack_import__("[next]/entry/app/layout-entry.tsx (ecmascript, client chunks, rsc)");
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$http$2e$ts__$28$ecmascript$29$__ = __turbopack_import__("[next]/internal/http.ts (ecmascript, ssr)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
"TURBOPACK { chunking-type: isolatedParallel }";
;
"TURBOPACK { chunking-type: isolatedParallel }";
;
;
const LOADER_TREE = [
    "",
    {
        "children": [
            "__PAGE__",
            {},
            {
                "page": [
                    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$page$2e$tsx__$28$ecmascript$2c$__client__chunks$29$__["default"],
                    JSON.stringify(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$page$2e$tsx__$28$ecmascript$2c$__client__chunks$29$__["chunks"]) + '.js'
                ]
            }
        ]
    },
    {
        "layout": [
            ()=>__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$layout$2e$tsx__$28$ecmascript$2c$__client__chunks$29$__["default"],
            JSON.stringify(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$layout$2e$tsx__$28$ecmascript$2c$__client__chunks$29$__["chunks"]) + '.js'
        ],
        metadata: {
            icon: [
                async (props)=>[
                        {
                            url: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$favicon$2e$ico$2f28$IMAGE$292f5b$project$5d2f$app$2f$favicon$2e$ico__$28$static$29$__$28$structured__image__object$2c$__ecmascript$29$__["default"].src,
                            sizes: `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$favicon$2e$ico$2f28$IMAGE$292f5b$project$5d2f$app$2f$favicon$2e$ico__$28$static$29$__$28$structured__image__object$2c$__ecmascript$29$__["default"].width}x${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$favicon$2e$ico$2f28$IMAGE$292f5b$project$5d2f$app$2f$favicon$2e$ico__$28$static$29$__$28$structured__image__object$2c$__ecmascript$29$__["default"].height}`
                        }
                    ]
            ]
        }
    }
];
;
;
;
;
;
;
'TURBOPACK { transition: next-layout-entry; chunking-type: isolatedParallel }';
;
;
globalThis.__next_require__ = (data)=>{
    const [, , ssr_id] = JSON.parse(data);
    return __turbopack_require__(ssr_id);
};
globalThis.__next_chunk_load__ = ()=>Promise.resolve();
process.env.__NEXT_NEW_LINK_BEHAVIOR = 'true';
const ipc = __TURBOPACK__imported__module__$5b$turbopack$2d$node$5d2f$ipc$2f$index$2e$ts__$28$ecmascript$29$__["IPC"];
const MIME_TEXT_HTML_UTF8 = 'text/html; charset=utf-8';
(async ()=>{
    while(true){
        const msg = await ipc.recv();
        let renderData;
        switch(msg.type){
            case 'headers':
                {
                    renderData = msg.data;
                    break;
                }
            default:
                {
                    console.error('unexpected message type', msg.type);
                    process.exit(1);
                }
        }
        const result = await runOperation(renderData);
        if (result == null) {
            throw new Error('no html returned');
        }
        ipc.send({
            type: 'headers',
            data: {
                status: result.statusCode,
                headers: result.headers
            }
        });
        for await (const chunk of result.body){
            ipc.send({
                type: 'bodyChunk',
                data: chunk.toJSON().data
            });
        }
        ipc.send({
            type: 'bodyEnd'
        });
    }
})().catch((err)=>{
    ipc.sendError(err);
});
async function runOperation(renderData) {
    const proxyMethodsForModule = (id)=>{
        return {
            get (_target, prop) {
                return {
                    id,
                    chunks: JSON.parse(id)[1],
                    name: prop
                };
            }
        };
    };
    const proxyMethodsNested = (type)=>{
        return {
            get (_target, key) {
                if (type === 'ssrModuleMapping') {
                    return new Proxy({}, proxyMethodsForModule(key));
                }
                if (type === 'clientModules') {
                    const pos = key.lastIndexOf('#');
                    let id = key;
                    let name = '';
                    if (pos !== -1) {
                        id = key.slice(0, pos);
                        name = key.slice(pos + 1);
                    } else {
                        throw new Error('keys need to be formatted as {file}#{name}');
                    }
                    return {
                        id,
                        name,
                        chunks: JSON.parse(id)[1]
                    };
                }
            }
        };
    };
    const proxyMethods = ()=>{
        const clientModulesProxy = new Proxy({}, proxyMethodsNested('clientModules'));
        const ssrModuleMappingProxy = new Proxy({}, proxyMethodsNested('ssrModuleMapping'));
        return {
            get (_target, prop) {
                if (prop === 'ssrModuleMapping') {
                    return ssrModuleMappingProxy;
                }
                if (prop === 'clientModules') {
                    return clientModulesProxy;
                }
                if (prop === 'cssFiles') {
                    return new Proxy({}, cssFilesProxyMethods);
                }
            }
        };
    };
    const availableModules = new Set();
    const toPath = (chunk)=>typeof chunk === 'string' ? chunk : chunk.path;
    const filterAvailable = (chunk)=>{
        if (typeof chunk === 'string') {
            return true;
        } else {
            let includedList = chunk.included || [];
            if (includedList.length === 0) {
                return true;
            }
            let needed = false;
            for (const item of includedList){
                if (!availableModules.has(item)) {
                    availableModules.add(item);
                    needed = true;
                }
            }
            return needed;
        }
    };
    const cssFilesProxyMethods = {
        get (_target, prop) {
            const cssChunks = JSON.parse(prop);
            return cssChunks.map(toPath);
        }
    };
    const cssImportProxyMethods = {
        get (_target, prop) {
            const cssChunks = JSON.parse(prop.replace(/\.js$/, ''));
            return cssChunks.filter(filterAvailable).map(toPath).map((chunk)=>JSON.stringify([
                    chunk,
                    [
                        chunk
                    ]
                ]));
        }
    };
    const manifest = new Proxy({}, proxyMethods());
    const serverCSSManifest = {
        cssImports: new Proxy({}, cssImportProxyMethods),
        cssModules: {}
    };
    const req = {
        url: renderData.originalUrl,
        method: renderData.method,
        headers: __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$headers$2e$ts__$28$ecmascript$29$__["initProxiedHeaders"](__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$headers$2e$ts__$28$ecmascript$29$__["headersFromEntries"](renderData.rawHeaders), renderData.data?.serverInfo)
    };
    const res = __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$http$2e$ts__$28$ecmascript$29$__["createServerResponse"](req, renderData.path);
    const query = __TURBOPACK__external__node$3a$querystring__["parse"](renderData.rawQuery);
    const renderOpt = {
        params: renderData.params,
        supportsDynamicHTML: true,
        dev: true,
        buildManifest: {
            polyfillFiles: [],
            rootMainFiles: __TURBOPACK__imported__module__$5b$next$5d2f$entry$2f$app$2f$hydrate$2e$tsx__$28$ecmascript$2c$__chunk__group__files$29$__["default"].filter((path)=>path.endsWith('.js')),
            devFiles: [],
            ampDevFiles: [],
            lowPriorityFiles: [],
            pages: {
                '/_app': []
            },
            ampFirstPages: []
        },
        ComponentMod: {
            ...__TURBOPACK__imported__module__$5b$next$5d2f$entry$2f$app$2f$layout$2d$entry$2e$tsx__$28$ecmascript$2c$__client__chunks$29$__["default"],
            default: undefined,
            tree: LOADER_TREE,
            pages: [
                'page.js'
            ]
        },
        clientReferenceManifest: manifest,
        serverCSSManifest,
        runtime: 'nodejs',
        serverComponents: true,
        assetPrefix: '',
        pageConfig: {},
        reactLoadableManifest: {},
        nextConfigOutput: renderData.data?.nextConfigOutput
    };
    const result = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$app$2d$render$2f$app$2d$render$2e$js__$28$ecmascript$29$__["renderToHTMLOrFlight"](req, res, renderData.path, query, renderOpt);
    if (!result || result.isNull()) throw new Error('rendering was not successful');
    const body = new __TURBOPACK__external__node$3a$stream__["PassThrough"]();
    if (result.isDynamic()) {
        result.pipe(body);
    } else {
        body.write(result.toUnchunkedString());
    }
    return {
        statusCode: res.statusCode,
        headers: [
            [
                'Content-Type',
                result.contentType() ?? MIME_TEXT_HTML_UTF8
            ],
            [
                'Vary',
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$app$2d$router$2d$headers$2e$js__$28$ecmascript$29$__["RSC_VARY_HEADER"]
            ]
        ],
        body
    };
}
const ESCAPE_LOOKUP = {
    '&': '\\u0026',
    '>': '\\u003e',
    '<': '\\u003c',
    '\u2028': '\\u2028',
    '\u2029': '\\u2029'
};
const ESCAPE_REGEX = /[&><\u2028\u2029]/g;
function htmlEscapeJsonString(str) {
    return str.replace(ESCAPE_REGEX, (match)=>ESCAPE_LOOKUP[match]);
}

})()),
}]);

//# sourceMappingURL=[next]_entry_app-renderer.tsx_3f46d9._.js.map