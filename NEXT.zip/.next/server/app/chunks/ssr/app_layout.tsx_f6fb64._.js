(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["chunks/ssr/app_layout.tsx_f6fb64._.js", {

"[project]/app/layout.tsx (ecmascript, client chunks, rsc)": (({ r: __turbopack_require__, x: __turbopack_external_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_cjs__, k: __turbopack_refresh__, g: global, __dirname }) => (() => {

__turbopack_esm__({
    default: () => __turbopack_import__("[project]/app/layout.tsx (ecmascript, rsc)"),
    chunks: () => chunks,
});
const chunks = [
  "chunks/rsc/[next]_internal_font_google_inter_59dee874.module_b5a149.css",
  "chunks/rsc/app_globals.css"
];

})()),
}]);