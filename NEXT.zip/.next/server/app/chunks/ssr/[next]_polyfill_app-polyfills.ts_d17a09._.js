(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["chunks/ssr/[next]_polyfill_app-polyfills.ts_d17a09._.js", {

"[next]/polyfill/async-local-storage.js (ecmascript, ssr)": (({ r: __turbopack_require__, x: __turbopack_external_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_cjs__, k: __turbopack_refresh__, g: global, __dirname }) => (() => {

var __TURBOPACK__external__node$3a$async_hooks__ = __turbopack_external_require__("node:async_hooks", true);
"__TURBOPACK__ecmascript__hoisting__location__";
;
globalThis.AsyncLocalStorage = __TURBOPACK__external__node$3a$async_hooks__["AsyncLocalStorage"];

})()),
"[next]/polyfill/app-polyfills.ts (ecmascript, ssr)": (function({ r: __turbopack_require__, x: __turbopack_external_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_cjs__, k: __turbopack_refresh__, g: global, __dirname, m: module, e: exports }) { !function() {

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$node$2d$polyfill$2d$fetch$2e$js__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/node-polyfill-fetch.js (ecmascript, ssr)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$node$2d$polyfill$2d$web$2d$streams$2e$js__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/node-polyfill-web-streams.js (ecmascript, ssr)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$node$2d$polyfill$2d$headers$2e$js__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/node-polyfill-headers.js (ecmascript, ssr)");
var __TURBOPACK__imported__module__$5b$next$5d2f$polyfill$2f$async$2d$local$2d$storage$2e$js__$28$ecmascript$29$__ = __turbopack_import__("[next]/polyfill/async-local-storage.js (ecmascript, ssr)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;

}.call(this) }),
}]);

//# sourceMappingURL=[next]_polyfill_app-polyfills.ts_d17a09._.js.map