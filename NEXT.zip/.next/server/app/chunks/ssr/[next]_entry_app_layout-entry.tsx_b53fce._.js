(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["chunks/ssr/[next]_entry_app_layout-entry.tsx_b53fce._.js", {

"[next]/entry/app/layout-entry.tsx (ecmascript, rsc)": (({ r: __turbopack_require__, x: __turbopack_external_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_cjs__, k: __turbopack_refresh__, g: global, __dirname }) => (() => {

__turbopack_esm__({
    "AppRouter": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$app$2d$router$2e$js__$28$ecmascript$29$__["default"],
    "GlobalError": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$error$2d$boundary$2e$js__$28$ecmascript$29$__["default"],
    "LayoutRouter": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$layout$2d$router$2e$js__$28$ecmascript$29$__["default"],
    "RenderFromTemplateContext": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$render$2d$from$2d$template$2d$context$2e$js__$28$ecmascript$29$__["default"],
    "StaticGenerationSearchParamsBailoutProvider": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$static$2d$generation$2d$searchparams$2d$bailout$2d$provider$2e$js__$28$ecmascript$29$__["default"],
    "actionAsyncStorage": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$action$2d$async$2d$storage$2e$js__$28$ecmascript$29$__["actionAsyncStorage"],
    "createSearchParamsBailoutProxy": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$searchparams$2d$bailout$2d$proxy$2e$js__$28$ecmascript$29$__["createSearchParamsBailoutProxy"],
    "decodeReply": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$server$2d$dom$2d$webpack$2f$server$2e$edge$2e$js__$28$ecmascript$29$__["decodeReply"],
    "preconnect": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$app$2d$render$2f$rsc$2f$preloads$2e$js__$28$ecmascript$29$__["preconnect"],
    "preloadFont": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$app$2d$render$2f$rsc$2f$preloads$2e$js__$28$ecmascript$29$__["preloadFont"],
    "preloadStyle": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$app$2d$render$2f$rsc$2f$preloads$2e$js__$28$ecmascript$29$__["preloadStyle"],
    "renderToReadableStream": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$server$2d$dom$2d$webpack$2f$server$2e$edge$2e$js__$28$ecmascript$29$__["renderToReadableStream"],
    "requestAsyncStorage": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$request$2d$async$2d$storage$2e$js__$28$ecmascript$29$__["requestAsyncStorage"],
    "serverHooks": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$hooks$2d$server$2d$context$2e$js__$28$ecmascript$29$__,
    "staticGenerationAsyncStorage": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$static$2d$generation$2d$async$2d$storage$2e$js__$28$ecmascript$29$__["staticGenerationAsyncStorage"],
    "staticGenerationBailout": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$static$2d$generation$2d$bailout$2e$js__$28$ecmascript$29$__["staticGenerationBailout"]
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$app$2d$router$2e$js__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/client/components/app-router.js (ecmascript, rsc)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$layout$2d$router$2e$js__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/client/components/layout-router.js (ecmascript, rsc)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$render$2d$from$2d$template$2d$context$2e$js__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/client/components/render-from-template-context.js (ecmascript, rsc)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$error$2d$boundary$2e$js__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/client/components/error-boundary.js (ecmascript, rsc)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$static$2d$generation$2d$async$2d$storage$2e$js__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/client/components/static-generation-async-storage.js (ecmascript, rsc)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$request$2d$async$2d$storage$2e$js__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/client/components/request-async-storage.js (ecmascript, rsc)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$action$2d$async$2d$storage$2e$js__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/client/components/action-async-storage.js (ecmascript, rsc)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$static$2d$generation$2d$bailout$2e$js__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/client/components/static-generation-bailout.js (ecmascript, rsc)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$static$2d$generation$2d$searchparams$2d$bailout$2d$provider$2e$js__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js (ecmascript, rsc)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$searchparams$2d$bailout$2d$proxy$2e$js__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/client/components/searchparams-bailout-proxy.js (ecmascript, rsc)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$hooks$2d$server$2d$context$2e$js__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/client/components/hooks-server-context.js (ecmascript, rsc)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$server$2d$dom$2d$webpack$2f$server$2e$edge$2e$js__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react-server-dom-webpack/server.edge.js (ecmascript, rsc)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$app$2d$render$2f$rsc$2f$preloads$2e$js__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/app-render/rsc/preloads.js (ecmascript, rsc)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;
;
;
;
;
;
;
;
;
;
;

})()),
}]);

//# sourceMappingURL=[next]_entry_app_layout-entry.tsx_b53fce._.js.map