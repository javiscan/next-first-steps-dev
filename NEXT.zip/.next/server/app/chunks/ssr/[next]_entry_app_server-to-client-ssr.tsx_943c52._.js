(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["chunks/ssr/[next]_entry_app_server-to-client-ssr.tsx_943c52._.js", {

"[next]/entry/app/server-to-client-ssr.tsx/(CLIENT_MODULE)/[project]/node_modules/next/dist/client/link.js (ecmascript, with chunking context scope)/(CLIENT_CHUNKS)/[project]/node_modules/next/dist/client/link.js (ecmascript, chunks) (ecmascript, rsc)": (({ r: __turbopack_require__, x: __turbopack_external_require__, f: __turbopack_require_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, l: __turbopack_load__, j: __turbopack_cjs__, k: __turbopack_refresh__, g: global, __dirname }) => (() => {

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$module$2d$proxy$2e$js__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js (ecmascript, rsc)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$link$2e$js__$28$ecmascript$2c$__with__chunking__context__scope$29$__ = __turbopack_import__("[project]/node_modules/next/dist/client/link.js (ecmascript, ssr)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$link$2e$js__$28$ecmascript$2c$__chunks$29$__ = __turbopack_import__("[project]/node_modules/next/dist/client/link.js (ecmascript, chunks, rsc)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
'TURBOPACK { chunking-type: isolatedParallel }';
;
;
const __TURBOPACK__default__export__ = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$module$2d$proxy$2e$js__$28$ecmascript$29$__["createProxy"](JSON.stringify([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$link$2e$js__$28$ecmascript$2c$__chunks$29$__["default"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$link$2e$js__$28$ecmascript$2c$__chunks$29$__["chunks"],
    "[project]/node_modules/next/dist/client/link.js (ecmascript, ssr)"
]));

})()),
}]);

//# sourceMappingURL=[next]_entry_app_server-to-client-ssr.tsx_943c52._.js.map